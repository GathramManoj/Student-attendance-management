import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  users: User[];
  addUser: (userData: Omit<User, 'id' | 'createdAt'>, password: string) => void;
  getUsersByRole: (role: string) => User[];
  getUsersByCreator: (creatorId: string) => User[];
  removeUser: (userId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Mock users data - in production, this would come from Google Sheets
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'admin',
      name: 'System Administrator',
      role: 'ADMIN',
      createdAt: new Date('2024-01-01'),
    },
    {
      id: '2',
      username: 'hod.cse',
      name: 'Dr. John Smith',
      role: 'HOD',
      department: 'Computer Science',
      createdBy: '1',
      createdAt: new Date('2024-01-02'),
    },
    {
      id: '3',
      username: 'cod.cse',
      name: 'Prof. Sarah Johnson',
      role: 'COD',
      department: 'Computer Science',
      createdBy: '2',
      createdAt: new Date('2024-01-03'),
    },
    {
      id: '4',
      username: 'cr.cse.3a',
      name: 'Alex Kumar',
      role: 'CR',
      department: 'Computer Science',
      createdBy: '2',
      createdAt: new Date('2024-01-04'),
    },
  ]);

  // Store user passwords (in production, this would be handled securely)
  const [userPasswords, setUserPasswords] = useState<{ [key: string]: string }>({
    'admin': 'password123',
    'hod.cse': 'password123',
    'cod.cse': 'password123',
    'cr.cse.3a': 'password123',
  });

  useEffect(() => {
    // Check for saved user in localStorage
    const savedUser = localStorage.getItem('attendanceUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock authentication - in production, this would validate against Google Sheets
    const foundUser = users.find(u => u.username === username);
    
    if (foundUser && userPasswords[username] === password) {
      setUser(foundUser);
      localStorage.setItem('attendanceUser', JSON.stringify(foundUser));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('attendanceUser');
  };

  const addUser = (userData: Omit<User, 'id' | 'createdAt'>, password: string) => {
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setUsers(prev => [...prev, newUser]);
    
    // Set custom password for new user
    setUserPasswords(prev => ({
      ...prev,
      [userData.username]: password
    }));
  };

  const getUsersByRole = (role: string): User[] => {
    return users.filter(u => u.role === role);
  };

  const getUsersByCreator = (creatorId: string): User[] => {
    return users.filter(u => u.createdBy === creatorId);
  };

  const removeUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
    // Also remove from passwords
    const userToRemove = users.find(u => u.id === userId);
    if (userToRemove) {
      setUserPasswords(prev => {
        const newPasswords = { ...prev };
        delete newPasswords[userToRemove.username];
        return newPasswords;
      });
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout, 
      isLoading, 
      users, 
      addUser, 
      getUsersByRole, 
      getUsersByCreator,
      removeUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};