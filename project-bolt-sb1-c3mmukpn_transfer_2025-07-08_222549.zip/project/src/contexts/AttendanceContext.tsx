import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Student, AttendanceRecord, AttendanceFilters } from '../types';

interface AttendanceContextType {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  addStudent: (student: Omit<Student, 'id' | 'addedAt'>) => void;
  removeStudent: (studentId: string) => void;
  markAttendance: (attendance: Omit<AttendanceRecord, 'id' | 'markedAt'>) => void;
  getAttendanceByFilters: (filters: AttendanceFilters) => AttendanceRecord[];
  getStudentsByYearSection: (year: number, section: string) => Student[];
  getTodayAttendanceStats: (year: number, section: string) => {
    totalStudents: number;
    presentToday: number;
    absentToday: number;
    periodsMarked: number;
  };
}

const AttendanceContext = createContext<AttendanceContextType | undefined>(undefined);

export const useAttendance = () => {
  const context = useContext(AttendanceContext);
  if (context === undefined) {
    throw new Error('useAttendance must be used within an AttendanceProvider');
  }
  return context;
};

interface AttendanceProviderProps {
  children: ReactNode;
}

export const AttendanceProvider: React.FC<AttendanceProviderProps> = ({ children }) => {
  // Mock data - in production, this would sync with Google Sheets
  const [students, setStudents] = useState<Student[]>([
    {
      id: '1',
      name: 'Rahul Sharma',
      regNo: '21CSE001',
      year: 3,
      section: 'A',
      department: 'Computer Science',
      addedBy: '4',
      addedAt: new Date('2024-01-10'),
    },
    {
      id: '2',
      name: 'Priya Patel',
      regNo: '21CSE002',
      year: 3,
      section: 'A',
      department: 'Computer Science',
      addedBy: '4',
      addedAt: new Date('2024-01-10'),
    },
    {
      id: '3',
      name: 'Amit Singh',
      regNo: '21CSE003',
      year: 3,
      section: 'A',
      department: 'Computer Science',
      addedBy: '4',
      addedAt: new Date('2024-01-10'),
    },
  ]);

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  const addStudent = (studentData: Omit<Student, 'id' | 'addedAt'>) => {
    const newStudent: Student = {
      ...studentData,
      id: Date.now().toString(),
      addedAt: new Date(),
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const removeStudent = (studentId: string) => {
    setStudents(prev => prev.filter(student => student.id !== studentId));
    setAttendanceRecords(prev => prev.filter(record => record.studentId !== studentId));
  };

  const markAttendance = (attendanceData: Omit<AttendanceRecord, 'id' | 'markedAt'>) => {
    const newRecord: AttendanceRecord = {
      ...attendanceData,
      id: Date.now().toString(),
      markedAt: new Date(),
    };
    setAttendanceRecords(prev => [...prev, newRecord]);
  };

  const getAttendanceByFilters = (filters: AttendanceFilters): AttendanceRecord[] => {
    return attendanceRecords.filter(record => 
      record.year === filters.year &&
      record.section === filters.section &&
      record.period === filters.period &&
      record.date === filters.date
    );
  };

  const getStudentsByYearSection = (year: number, section: string): Student[] => {
    return students.filter(student => 
      student.year === year && student.section === section
    );
  };

  const getTodayAttendanceStats = (year: number, section: string) => {
    const todayDate = new Date().toISOString().split('T')[0];
    const classStudents = getStudentsByYearSection(year, section);
    const totalStudents = classStudents.length;
    
    // Get today's attendance records for this class
    const todayRecords = attendanceRecords.filter(record => 
      record.year === year &&
      record.section === section &&
      record.date === todayDate
    );
    
    // Get unique students who have attendance marked today
    const studentsWithAttendance = new Set(todayRecords.map(record => record.studentId));
    
    // Count present and absent students
    let presentToday = 0;
    let absentToday = 0;
    
    studentsWithAttendance.forEach(studentId => {
      // Get the latest record for this student today (in case of multiple periods)
      const studentRecords = todayRecords
        .filter(record => record.studentId === studentId)
        .sort((a, b) => b.period - a.period); // Sort by period descending
      
      if (studentRecords.length > 0) {
        const latestRecord = studentRecords[0];
        if (latestRecord.status === 'present' || latestRecord.status === 'late') {
          presentToday++;
        } else {
          absentToday++;
        }
      }
    });
    
    // If no attendance marked yet, assume all absent
    if (studentsWithAttendance.size === 0) {
      absentToday = totalStudents;
    } else {
      // Students without any attendance record are considered absent
      absentToday += totalStudents - studentsWithAttendance.size;
    }
    
    // Count unique periods marked today
    const periodsMarked = new Set(todayRecords.map(record => record.period)).size;
    
    return {
      totalStudents,
      presentToday,
      absentToday,
      periodsMarked
    };
  };

  return (
    <AttendanceContext.Provider value={{
      students,
      attendanceRecords,
      addStudent,
      removeStudent,
      markAttendance,
      getAttendanceByFilters,
      getStudentsByYearSection,
      getTodayAttendanceStats,
    }}>
      {children}
    </AttendanceContext.Provider>
  );
};