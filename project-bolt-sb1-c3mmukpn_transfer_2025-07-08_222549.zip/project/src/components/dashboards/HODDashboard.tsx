import React, { useState } from 'react';
import { Users, Plus, UserCheck, Calendar, GraduationCap, User, Trash2 } from 'lucide-react';
import Header from '../shared/Header';
import StatCard from '../shared/StatCard';
import AddUserModal from '../modals/AddUserModal';
import AttendanceViewer from '../attendance/AttendanceViewer';
import { useAuth } from '../../contexts/AuthContext';

const HODDashboard: React.FC = () => {
  const [showAddUser, setShowAddUser] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'attendance'>('overview');
  const { user, getUsersByCreator, getUsersByRole, removeUser } = useAuth();

  // Get users created by this HOD
  const myUsers = user ? getUsersByCreator(user.id) : [];
  const myCODs = myUsers.filter(u => u.role === 'COD');
  const myCRs = myUsers.filter(u => u.role === 'CR');
  
  // Get all CODs and CRs for department stats
  const allCODs = getUsersByRole('COD');
  const allCRs = getUsersByRole('CR');

  const handleRemoveUser = (userId: string, userName: string) => {
    if (window.confirm(`Are you sure you want to remove ${userName}? This action cannot be undone.`)) {
      removeUser(userId);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: GraduationCap },
    { id: 'users', label: 'Manage Users', icon: Users },
    { id: 'attendance', label: 'View Attendance', icon: Calendar },
  ];

  return (
    <div>
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">HOD Dashboard</h2>
          <p className="text-gray-600">Manage department users and monitor attendance</p>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-5 w-5 inline mr-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {activeTab === 'overview' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title="My CODs"
                value={myCODs.length.toString()}
                icon={Users}
                color="bg-purple-500"
                description="Added by me"
              />
              <StatCard
                title="My CRs"
                value={myCRs.length.toString()}
                icon={UserCheck}
                color="bg-green-500"
                description="Added by me"
              />
              <StatCard
                title="Total CODs"
                value={allCODs.length.toString()}
                icon={Users}
                color="bg-blue-500"
                description="System wide"
              />
              <StatCard
                title="Total CRs"
                value={allCRs.length.toString()}
                icon={Calendar}
                color="bg-orange-500"
                description="System wide"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* My CODs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Users className="h-5 w-5 text-purple-500 mr-2" />
                    My Course Coordinators ({myCODs.length})
                  </h3>
                </div>
                <div className="p-4">
                  {myCODs.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-4">No CODs added yet</p>
                  ) : (
                    <div className="space-y-3">
                      {myCODs.map((cod) => (
                        <div key={cod.id} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                          <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                            <User className="h-4 w-4 text-purple-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{cod.name}</p>
                            <p className="text-xs text-gray-500 truncate">{cod.department}</p>
                            <p className="text-xs text-gray-400">@{cod.username}</p>
                            <p className="text-xs text-gray-400">Added: {cod.createdAt.toLocaleDateString()}</p>
                          </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(cod.id, cod.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* My CRs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <UserCheck className="h-5 w-5 text-green-500 mr-2" />
                    My Class Representatives ({myCRs.length})
                  </h3>
                </div>
                <div className="p-4">
                  {myCRs.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-4">No CRs added yet</p>
                  ) : (
                    <div className="space-y-3">
                      {myCRs.map((cr) => (
                        <div key={cr.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                            <User className="h-4 w-4 text-green-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{cr.name}</p>
                            <p className="text-xs text-gray-500 truncate">{cr.department}</p>
                            <p className="text-xs text-gray-400">@{cr.username}</p>
                            <p className="text-xs text-gray-400">Added: {cr.createdAt.toLocaleDateString()}</p>
                          </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(cr.id, cr.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">User Management</h3>
                <button
                  onClick={() => setShowAddUser(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add User
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-purple-50 border border-purple-200 rounded-md p-4">
                <p className="text-purple-800 text-sm">
                  <strong>HOD Privileges:</strong> You can add CODs (Course Coordinators) and CRs (Class Representatives) 
                  within your department. CRs will be able to mark attendance and manage students.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'attendance' && (
          <AttendanceViewer />
        )}
      </div>

      {showAddUser && (
        <AddUserModal
          onClose={() => setShowAddUser(false)}
          allowedRoles={['COD', 'CR']}
        />
      )}
    </div>
  );
};

export default HODDashboard;