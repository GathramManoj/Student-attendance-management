import React, { useState } from 'react';
import { Users, Plus, UserCheck, Calendar, Clock } from 'lucide-react';
import Header from '../shared/Header';
import StatCard from '../shared/StatCard';
import StudentManager from '../students/StudentManager';
import AttendanceMarker from '../attendance/AttendanceMarker';
import AttendanceViewer from '../attendance/AttendanceViewer';
import { useAttendance } from '../../contexts/AttendanceContext';
import { useAuth } from '../../contexts/AuthContext';

const CRDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'students' | 'attendance' | 'reports'>('overview');
  const { getTodayAttendanceStats } = useAttendance();
  const { user } = useAuth();
  
  // For demo purposes, assuming CR manages Year 3 Section A
  // In production, this would be determined by the CR's assignment
  const crYear = 3;
  const crSection = 'A';
  
  const stats = getTodayAttendanceStats(crYear, crSection);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: UserCheck },
    { id: 'students', label: 'Manage Students', icon: Users },
    { id: 'attendance', label: 'Mark Attendance', icon: Clock },
    { id: 'reports', label: 'View Reports', icon: Calendar },
  ];

  return (
    <div>
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">CR Dashboard</h2>
          <p className="text-gray-600">Manage students and mark attendance for your class</p>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-green-500 text-green-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-5 w-5 inline mr-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Total Students"
              value={stats.totalStudents.toString()}
              icon={Users}
              color="bg-green-500"
              description="In your class"
            />
            <StatCard
              title="Present Today"
              value={stats.presentToday.toString()}
              icon={UserCheck}
              color="bg-blue-500"
              description={`${stats.totalStudents > 0 ? Math.round((stats.presentToday / stats.totalStudents) * 100) : 0}% attendance`}
            />
            <StatCard
              title="Absent Today"
              value={stats.absentToday.toString()}
              icon={Users}
              color="bg-red-500"
              description={`${stats.totalStudents > 0 ? Math.round((stats.absentToday / stats.totalStudents) * 100) : 0}% absent`}
            />
            <StatCard
              title="Periods Marked"
              value={stats.periodsMarked.toString()}
              icon={Clock}
              color="bg-purple-500"
              description="Out of 7 periods"
            />
          </div>
        )}

        {activeTab === 'students' && <StudentManager />}
        {activeTab === 'attendance' && <AttendanceMarker />}
        {activeTab === 'reports' && <AttendanceViewer />}
      </div>
    </div>
  );
};

export default CRDashboard;