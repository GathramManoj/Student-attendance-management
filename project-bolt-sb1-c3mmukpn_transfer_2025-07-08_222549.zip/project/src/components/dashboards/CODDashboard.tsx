import React, { useState } from 'react';
import { Calendar, Users, BookOpen, TrendingUp, User, Plus, Trash2 } from 'lucide-react';
import Header from '../shared/Header';
import StatCard from '../shared/StatCard';
import AttendanceViewer from '../attendance/AttendanceViewer';
import AddUserModal from '../modals/AddUserModal';
import { useAuth } from '../../contexts/AuthContext';

const CODDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'attendance'>('overview');
  const [showAddUser, setShowAddUser] = useState(false);
  const { user, getUsersByCreator, getUsersByRole, removeUser } = useAuth();

  // Get users created by this COD
  const myUsers = user ? getUsersByCreator(user.id) : [];
  const myCRs = myUsers.filter(u => u.role === 'CR');
  
  // Get all CRs for system stats
  const allCRs = getUsersByRole('CR');

  const handleRemoveUser = (userId: string, userName: string) => {
    if (window.confirm(`Are you sure you want to remove ${userName}? This action cannot be undone.`)) {
      removeUser(userId);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BookOpen },
    { id: 'users', label: 'Manage Users', icon: Users },
    { id: 'attendance', label: 'View Attendance', icon: Calendar },
  ];

  return (
    <div>
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">COD Dashboard</h2>
          <p className="text-gray-600">Monitor course attendance and manage class representatives</p>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-5 w-5 inline mr-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {activeTab === 'overview' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title="My CRs"
                value={myCRs.length.toString()}
                icon={Users}
                color="bg-blue-500"
                description="Added by me"
              />
              <StatCard
                title="Total CRs"
                value={allCRs.length.toString()}
                icon={Users}
                color="bg-green-500"
                description="System wide"
              />
              <StatCard
                title="Avg Attendance"
                value="87%"
                icon={TrendingUp}
                color="bg-orange-500"
                description="This month"
              />
              <StatCard
                title="Classes Today"
                value="4"
                icon={Calendar}
                color="bg-purple-500"
                description="Scheduled"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
              {/* My CRs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium text-gray-900 flex items-center">
                      <Users className="h-5 w-5 text-blue-500 mr-2" />
                      My Class Representatives ({myCRs.length})
                    </h3>
                    <button
                      onClick={() => setShowAddUser(true)}
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add CR
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  {myCRs.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">No CRs added yet. Click "Add CR" to get started.</p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {myCRs.map((cr) => (
                        <div key={cr.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-100">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                              <User className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">{cr.name}</p>
                              <p className="text-xs text-gray-500 truncate">{cr.department}</p>
                              <p className="text-xs text-gray-400">@{cr.username}</p>
                              <p className="text-xs text-gray-400">Added: {cr.createdAt.toLocaleDateString()}</p>
                            </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(cr.id, cr.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">User Management</h3>
                <button
                  onClick={() => setShowAddUser(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add CR
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6">
                <p className="text-blue-800 text-sm">
                  <strong>COD Privileges:</strong> You can add CRs (Class Representatives) who will be able to mark attendance and manage students in their respective classes.
                </p>
              </div>

              {/* User List Table */}
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Username
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Department
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Added Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {myCRs.map((cr) => (
                      <tr key={cr.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                <User className="h-5 w-5 text-blue-600" />
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{cr.name}</div>
                              <div className="text-sm text-gray-500">Class Representative</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">@{cr.username}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{cr.department}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {cr.createdAt.toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => handleRemoveUser(cr.id, cr.name)}
                            className="text-red-600 hover:text-red-900 inline-flex items-center"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {myCRs.length === 0 && (
                  <div className="text-center py-8">
                    <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No CRs added yet</p>
                    <p className="text-sm text-gray-400 mt-2">
                      Click "Add CR" to create your first Class Representative
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'attendance' && (
          <AttendanceViewer />
        )}
      </div>

      {showAddUser && (
        <AddUserModal
          onClose={() => setShowAddUser(false)}
          allowedRoles={['CR']}
        />
      )}
    </div>
  );
};

export default CODDashboard;