import React, { useState } from 'react';
import { Users, Plus, UserCheck, Calendar, User, Shield, Trash2 } from 'lucide-react';
import Header from '../shared/Header';
import StatCard from '../shared/StatCard';
import AddUserModal from '../modals/AddUserModal';
import AttendanceViewer from '../attendance/AttendanceViewer';
import { useAuth } from '../../contexts/AuthContext';

const AdminDashboard: React.FC = () => {
  const [showAddUser, setShowAddUser] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'attendance'>('overview');
  const { getUsersByRole, removeUser } = useAuth();

  const hods = getUsersByRole('HOD');
  const cods = getUsersByRole('COD');
  const crs = getUsersByRole('CR');

  const handleRemoveUser = (userId: string, userName: string) => {
    if (window.confirm(`Are you sure you want to remove ${userName}? This action cannot be undone.`)) {
      removeUser(userId);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: UserCheck },
    { id: 'users', label: 'Manage Users', icon: Users },
    { id: 'attendance', label: 'View Attendance', icon: Calendar },
  ];

  return (
    <div>
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Admin Dashboard</h2>
          <p className="text-gray-600">Manage system users and view attendance reports</p>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-red-500 text-red-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-5 w-5 inline mr-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {activeTab === 'overview' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title="Total HODs"
                value={hods.length.toString()}
                icon={Users}
                color="bg-red-500"
                description="Department heads"
              />
              <StatCard
                title="Total CODs"
                value={cods.length.toString()}
                icon={Users}
                color="bg-blue-500"
                description="Course coordinators"
              />
              <StatCard
                title="Total CRs"
                value={crs.length.toString()}
                icon={UserCheck}
                color="bg-green-500"
                description="Class representatives"
              />
              <StatCard
                title="System Users"
                value={(hods.length + cods.length + crs.length + 1).toString()}
                icon={Shield}
                color="bg-purple-500"
                description="Total active users"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* HODs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Shield className="h-5 w-5 text-red-500 mr-2" />
                    Head of Departments ({hods.length})
                  </h3>
                </div>
                <div className="p-4">
                  {hods.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-4">No HODs added yet</p>
                  ) : (
                    <div className="space-y-3">
                      {hods.map((hod) => (
                        <div key={hod.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                          <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-red-100 rounded-full flex items-center justify-center mr-3">
                            <User className="h-4 w-4 text-red-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{hod.name}</p>
                            <p className="text-xs text-gray-500 truncate">{hod.department}</p>
                            <p className="text-xs text-gray-400">@{hod.username}</p>
                          </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(hod.id, hod.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* CODs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Users className="h-5 w-5 text-blue-500 mr-2" />
                    Course Coordinators ({cods.length})
                  </h3>
                </div>
                <div className="p-4">
                  {cods.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-4">No CODs added yet</p>
                  ) : (
                    <div className="space-y-3">
                      {cods.map((cod) => (
                        <div key={cod.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                          <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                            <User className="h-4 w-4 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{cod.name}</p>
                            <p className="text-xs text-gray-500 truncate">{cod.department}</p>
                            <p className="text-xs text-gray-400">@{cod.username}</p>
                          </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(cod.id, cod.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* CRs List */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <UserCheck className="h-5 w-5 text-green-500 mr-2" />
                    Class Representatives ({crs.length})
                  </h3>
                </div>
                <div className="p-4">
                  {crs.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-4">No CRs added yet</p>
                  ) : (
                    <div className="space-y-3">
                      {crs.map((cr) => (
                        <div key={cr.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                            <User className="h-4 w-4 text-green-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{cr.name}</p>
                            <p className="text-xs text-gray-500 truncate">{cr.department}</p>
                            <p className="text-xs text-gray-400">@{cr.username}</p>
                          </div>
                          </div>
                          <button
                            onClick={() => handleRemoveUser(cr.id, cr.name)}
                            className="text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100"
                            title="Remove user"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">User Management</h3>
                <button
                  onClick={() => setShowAddUser(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add HOD
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                <p className="text-blue-800 text-sm">
                  <strong>Admin Privileges:</strong> You can only add HODs (Head of Department). 
                  HODs can then add CODs and CRs within their departments.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'attendance' && (
          <AttendanceViewer />
        )}
      </div>

      {showAddUser && (
        <AddUserModal
          onClose={() => setShowAddUser(false)}
          allowedRoles={['HOD']}
        />
      )}
    </div>
  );
};

export default AdminDashboard;