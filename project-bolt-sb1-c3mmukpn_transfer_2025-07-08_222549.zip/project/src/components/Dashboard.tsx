import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import AdminDashboard from './dashboards/AdminDashboard';
import HODDashboard from './dashboards/HODDashboard';
import CODDashboard from './dashboards/CODDashboard';
import CRDashboard from './dashboards/CRDashboard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user) return null;

  const renderDashboard = () => {
    switch (user.role) {
      case 'ADMIN':
        return <AdminDashboard />;
      case 'HOD':
        return <HODDashboard />;
      case 'COD':
        return <CODDashboard />;
      case 'CR':
        return <CRDashboard />;
      default:
        return <div>Invalid role</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {renderDashboard()}
    </div>
  );
};

export default Dashboard;