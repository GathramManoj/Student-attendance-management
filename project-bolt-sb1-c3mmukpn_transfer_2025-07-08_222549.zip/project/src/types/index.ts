export interface User {
  id: string;
  username: string;
  name: string;
  role: 'ADMIN' | 'HOD' | 'COD' | 'CR';
  department?: string;
  createdBy?: string;
  createdAt: Date;
}

export interface Student {
  id: string;
  name: string;
  regNo: string;
  year: number;
  section: string;
  department: string;
  addedBy: string;
  addedAt: Date;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  regNo: string;
  year: number;
  section: string;
  date: string;
  period: number;
  status: 'present' | 'absent' | 'late';
  markedBy: string;
  markedAt: Date;
}

export interface AttendanceFilters {
  year: number;
  section: string;
  period: number;
  date: string;
}