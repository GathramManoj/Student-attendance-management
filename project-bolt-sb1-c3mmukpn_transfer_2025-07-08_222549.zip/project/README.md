# Student Attendance Management System

A comprehensive web-based attendance management system built with React, TypeScript, and Tailwind CSS. This system provides role-based access control for different user types including Admin, HOD (Head of Department), COD (Course Coordinator), and CR (Class Representative).

## 🚀 Features

### Role-Based Access Control
- **Admin**: Manage HODs and view system-wide attendance reports
- **HOD**: Manage CODs and CRs within their department
- **COD**: Manage CRs and view attendance reports
- **CR**: Manage students and mark attendance

### Core Functionality
- ✅ User management with hierarchical permissions
- ✅ Student registration and management
- ✅ Real-time attendance marking
- ✅ Attendance reports and analytics
- ✅ CSV export functionality
- ✅ Responsive design for all devices

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: Netlify

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/student-attendance-system.git
   cd student-attendance-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Build for production**
   ```bash
   npm run build
   ```

## 🔐 Demo Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | password123 |
| HOD | hod.cse | password123 |
| COD | cod.cse | password123 |
| CR | cr.cse.3a | password123 |

## 📱 User Roles & Permissions

### Admin Dashboard
- Add and remove HODs
- View all system users
- Access system-wide attendance reports
- Export attendance data

### HOD Dashboard
- Add and remove CODs and CRs
- View department-specific statistics
- Monitor attendance across department

### COD Dashboard
- Add and remove CRs
- View course-specific attendance
- Manage class representatives

### CR Dashboard
- Add and remove students
- Mark daily attendance (7 periods)
- View attendance statistics
- Generate attendance reports

## 🏗️ Project Structure

```
src/
├── components/
│   ├── attendance/          # Attendance marking and viewing
│   ├── dashboards/          # Role-specific dashboards
│   ├── modals/             # Modal components
│   ├── shared/             # Shared components
│   └── students/           # Student management
├── contexts/               # React contexts for state management
├── types/                  # TypeScript type definitions
└── main.tsx               # Application entry point
```

## 🔄 State Management

The application uses React Context API for state management:
- **AuthContext**: User authentication and management
- **AttendanceContext**: Student and attendance data management

## 📊 Features in Detail

### Attendance Management
- Mark attendance for multiple periods (1-7)
- Support for Present, Absent, and Late status
- Real-time statistics calculation
- Date-wise attendance tracking

### User Management
- Hierarchical user creation (Admin → HOD → COD/CR)
- Role-based permissions
- User removal with confirmation
- Automatic login capability for new users

### Reports & Analytics
- Daily attendance statistics
- Period-wise attendance tracking
- CSV export functionality
- Filterable attendance records

## 🚀 Deployment

The application is deployed on Netlify and can be accessed at: [Your Netlify URL]

To deploy your own instance:
1. Build the project: `npm run build`
2. Deploy the `dist` folder to your preferred hosting service

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit your changes: `git commit -m 'Add feature'`
4. Push to the branch: `git push origin feature-name`
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🐛 Known Issues

- Data is stored in local state (not persistent)
- No backend integration (uses mock data)
- Password validation is basic

## 🔮 Future Enhancements

- [ ] Backend integration with database
- [ ] Email notifications for attendance
- [ ] Mobile app development
- [ ] Advanced reporting features
- [ ] Integration with Google Sheets/Excel
- [ ] Biometric attendance support

## 📞 Support

For support and questions, please open an issue in the GitHub repository.

---

**Built with ❤️ using React and TypeScript**